<?php
class PostsController extends AppController{
	
	public $scaffold;
	
	/**
	 * 初期表示
	 */
	public function index(){
		$this->render('index');
	}
	
	/**
	 * 投稿処理
	 */
	public function post(){
		
//		if($this->request->is('post')){
			// 登録処理を行う。
//			$id = $this->Post->save($this->request->data);
	//  if (move_uploaded_file($tmp, $file)) {
        //  $this->Upload->create();
        //  $this->request->data['Post']['image'] = $file_name;	
		if($this->Post->save($this->request->data)){
      //画像保存先のパス
      $path = IMAGES;
      $image = $this->request->data['Post']['image'];
      $this->Session->setFlash('画像を登録しました');
      //move_uploaded_file($image['tmp_name'], '/webroot/media/' . DS . $image['name']);
    			
			// 登録後、参照画面にリダイレクトする。
			$this->redirect('/posts/view/'.$this->Post->id);
			return;
		}
	//	if (in_array($ext, $arr_ext)) {
	//		move_uploaded_file($ext2, APP_DIR . '/webroot/media/' . $file['name']);
	//		$this->request->data['Post']['photo'] = $file['name'];
//}
	
		$this->render('index');
	}
	
	/**
	 * 投稿データ参照
	 */
	
	public function view(){
		
		// 投稿idを取得する。
		$id = $this->request->pass[0];
		
		
		// データを取得する。
		$options = array('conditions' => array('Post.id' => $id));
		$data = $this->Post->find('all', $options);
		
		// 取得したデータをveiwにセットする。
		$this->set('data', $data);

		$this->render('view');
	}
}

