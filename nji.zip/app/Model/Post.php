<?php
class Post extends AppModel{

//	public $actsAs = array(
//		'Upload.Upload' => array(
//			'photo' => array(
//				'fields' => array(
//					'dir' => 'photo_dir'
//				)
//			)
//		)
//	);
//}



    public $actsAs = array(
        'Upload.Upload' => array(
            'photo' => array(
                'thumbnailSizes' => array(
                    'thumb150' => '150x150',
                    'thumb80' => '80x80',
                ),
                'thumbnailMethod' => 'php',
                'fields' => array('dir' => 'photo_dir', 'type' => 'type', 'size' => 'size'),
                'mimetypes' => array('image/jpeg', 'image/gif', 'image/png'),
                'extensions' => array('jpg', 'jpeg', 'JPG', 'JPEG', 'gif', 'GIF', 'png', 'PNG'),
                'maxSize' => 2097152, //2MB
            ),
    //        'photo_menu' => array(
      //          'thumbnailSizes' => array(
        //            'thumb' => '100x100'
          //      ),
             //   'thumbnailMethod' => 'php',
            //  'fields' => array('dir' => 'dir', 'type' => 'type', 'size' => 'size')
	//	),
	    'path' => '{ROOT}{DS}webroot{DS}files{DS}{field}aaa{DS}',
             'thumbnailMethod' => 'php', // GD利用
             'thumbnailName' => 'comThumbnail', // サムネイル名を指定
             'thumbnailType' => 'png', // サムネイルの拡張子をpng
            ),
    );
}
